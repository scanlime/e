#include <iostream>

using namespace std;

int main()
{
	while('e') cout << "e";
	return 'e';
}
