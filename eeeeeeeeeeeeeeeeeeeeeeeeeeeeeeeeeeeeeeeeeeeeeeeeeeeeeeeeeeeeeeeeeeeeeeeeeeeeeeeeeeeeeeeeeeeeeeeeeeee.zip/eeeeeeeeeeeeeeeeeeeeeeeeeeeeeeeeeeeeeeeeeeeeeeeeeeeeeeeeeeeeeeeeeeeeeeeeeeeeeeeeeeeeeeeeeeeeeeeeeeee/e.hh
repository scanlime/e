<?hh // strict

<<__Entrypoint>>
function main(): void {
  while(true) {
    echo 'e';
  }
}
