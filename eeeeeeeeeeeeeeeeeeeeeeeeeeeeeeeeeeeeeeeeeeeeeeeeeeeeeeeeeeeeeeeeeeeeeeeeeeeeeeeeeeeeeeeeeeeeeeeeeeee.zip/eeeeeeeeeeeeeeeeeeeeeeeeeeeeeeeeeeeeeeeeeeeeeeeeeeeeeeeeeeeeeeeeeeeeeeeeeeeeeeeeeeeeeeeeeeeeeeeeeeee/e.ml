let rec eee e = Printf.printf "e"; eee ();;
let () = eee ();;