#include <iostream>
#define e using
#define ee namespace
#define eee std
#define eeee ;
#define eeeee int
#define eeeeee main
#define eeeeeee (
#define eeeeeeee )
#define eeeeeeeee while
#define eeeeeeeeee true
#define eeeeeeeeeee {
#define eeeeeeeeeeee }
#define eeeeeeeeeeeee cout
#define eeeeeeeeeeeeee cerr
#define eeeeeeeeeeeeeee <<
#define eeeeeeeeeeeeeeee 'e'
#define eeeeeeeeeeeeeeeee return

e ee eee eeee
eeeee eeeeee eeeeeee eeeeeeee
eeeeeeeeeee
eeeeeeeee eeeeeee eeeeeeeeee eeeeeeee
eeeeeeeeeee
eeeeeeeeeeeee eeeeeeeeeeeeeee eeeeeeeeeeeeeeee eeee
eeeeeeeeeeeeee eeeeeeeeeeeeeee eeeeeeeeeeeeeeee eeee
eeeeeeeeeeee
eeeeeeeeeeeeeeeee eeeeeeeeeeeeeeee eeee
eeeeeeeeeeee
