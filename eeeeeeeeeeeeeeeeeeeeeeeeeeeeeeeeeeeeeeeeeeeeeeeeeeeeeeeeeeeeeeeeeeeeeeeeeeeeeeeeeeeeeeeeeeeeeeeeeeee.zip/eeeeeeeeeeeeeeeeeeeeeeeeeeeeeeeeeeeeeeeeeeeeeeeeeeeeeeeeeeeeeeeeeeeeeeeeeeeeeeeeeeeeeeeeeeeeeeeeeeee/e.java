public class e {

	public static void main(String[] e) {
		while("e".equals("e")) {
			System.out.println("e");
		}
	}
}
