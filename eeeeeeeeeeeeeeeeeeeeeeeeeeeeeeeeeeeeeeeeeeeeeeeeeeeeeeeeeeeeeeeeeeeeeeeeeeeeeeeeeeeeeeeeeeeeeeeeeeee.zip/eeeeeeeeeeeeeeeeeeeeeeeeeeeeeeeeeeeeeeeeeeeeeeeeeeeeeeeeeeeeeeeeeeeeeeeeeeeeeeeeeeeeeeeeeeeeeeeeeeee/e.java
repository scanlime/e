public class e {

	public static void main(String[] args) {
		while(true) {
			System.out.print("e");
		}
	}
}
