#![feature(main)]
#[main]
fn e() {
    loop {
        print!("e");
    }
}
