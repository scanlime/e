import Control.Monad.Fix
main = putStr $ fix ('e':)

