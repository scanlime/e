#include <stdio.h>

int main()
{
	for (;;) {
		printf("e");
	}
}

int on_exit()
{
	return 'e';
}
