fun main() {
    while (true) {
    	print("e")
    }
}
