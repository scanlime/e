fun main(args: Array<String>) {
    while (true) {
    	print("e")
    }
}
