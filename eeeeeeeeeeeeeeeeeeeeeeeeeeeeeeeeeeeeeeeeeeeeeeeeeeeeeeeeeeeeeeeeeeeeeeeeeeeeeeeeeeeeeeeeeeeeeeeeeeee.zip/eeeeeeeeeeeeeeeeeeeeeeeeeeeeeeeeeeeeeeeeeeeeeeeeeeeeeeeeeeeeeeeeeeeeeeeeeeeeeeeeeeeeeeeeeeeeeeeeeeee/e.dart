import 'dart:io';

main(List<String> args) {
  while (true) {
    stdout.write('e');
  }
}
