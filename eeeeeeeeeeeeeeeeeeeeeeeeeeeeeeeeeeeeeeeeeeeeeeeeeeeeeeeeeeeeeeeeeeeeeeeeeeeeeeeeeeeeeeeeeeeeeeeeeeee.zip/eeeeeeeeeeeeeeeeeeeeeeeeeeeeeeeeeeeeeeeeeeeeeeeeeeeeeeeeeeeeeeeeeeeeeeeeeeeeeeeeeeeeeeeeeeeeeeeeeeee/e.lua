while true do
    print('e')
end
