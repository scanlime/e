while(T)cat("e")
