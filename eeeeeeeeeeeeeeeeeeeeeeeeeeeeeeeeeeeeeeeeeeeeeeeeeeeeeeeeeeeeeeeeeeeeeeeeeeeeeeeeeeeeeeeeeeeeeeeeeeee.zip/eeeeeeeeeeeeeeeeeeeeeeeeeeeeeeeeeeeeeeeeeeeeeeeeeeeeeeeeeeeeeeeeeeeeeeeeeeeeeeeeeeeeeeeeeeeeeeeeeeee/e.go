package main

func main() {
	for {
		print("e")
	}
}
