package main

import (
	"fmt"
)

func main() {
	for {
		fmt.Print("e")
	}
}
