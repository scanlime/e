from __future__ import print_function

exec('''
         'eeeeee'\
      'eeee'\nimport\
    sys\n'    '\nwhile\
   True:        \n print\
  ('eee'         'eeeee'\
 'eeeeeeeeeeeeeeeeeeeee'\
 'eeee'\
  'eeeee'        'eeeee'\
   'eeeeeeeeeeeeeeeee'\
       'ee',end='')
'''[10:])
