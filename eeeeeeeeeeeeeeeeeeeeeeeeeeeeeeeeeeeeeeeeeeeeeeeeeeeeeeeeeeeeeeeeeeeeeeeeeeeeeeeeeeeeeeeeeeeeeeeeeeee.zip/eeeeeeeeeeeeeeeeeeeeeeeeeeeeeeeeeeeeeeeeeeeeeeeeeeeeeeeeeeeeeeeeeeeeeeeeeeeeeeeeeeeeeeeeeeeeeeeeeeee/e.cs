using System;

namespace e
{
    class E
    {
        const bool e = true;
        
        static void Main(string[] args)
        {
            while (e)
            {
                Console.Write('e');
            }
        }
    }
}
