using System;

namespace e
{
    class E
    {
        static void Main(string[] args)
        {
            Console.WriteLine('e');
        }
    }
}
