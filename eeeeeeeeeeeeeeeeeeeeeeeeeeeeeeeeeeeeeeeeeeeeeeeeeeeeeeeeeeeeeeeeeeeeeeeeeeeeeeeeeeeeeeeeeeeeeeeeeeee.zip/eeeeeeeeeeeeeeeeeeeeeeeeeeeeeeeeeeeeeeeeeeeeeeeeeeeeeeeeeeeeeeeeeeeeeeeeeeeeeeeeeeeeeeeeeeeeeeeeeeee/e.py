import sys

try:
	while True:
		sys.stdout.write('e')
except KeyboardInterrupt:
	sys.exit(0)
