import sys

try:
    while 'e':
        sys.stdout.write('e')
except KeyboardInterrupt as e:
    sys.exit('e')

