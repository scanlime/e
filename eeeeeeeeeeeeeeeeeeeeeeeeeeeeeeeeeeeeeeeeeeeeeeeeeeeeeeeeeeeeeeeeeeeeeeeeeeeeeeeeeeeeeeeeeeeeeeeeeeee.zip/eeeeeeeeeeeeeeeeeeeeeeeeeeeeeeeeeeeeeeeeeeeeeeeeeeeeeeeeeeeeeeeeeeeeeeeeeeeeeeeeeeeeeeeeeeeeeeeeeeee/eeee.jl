while true
    print("e")
end
