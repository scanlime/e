#!/bin/sh
yes e | tr -d '\n'
