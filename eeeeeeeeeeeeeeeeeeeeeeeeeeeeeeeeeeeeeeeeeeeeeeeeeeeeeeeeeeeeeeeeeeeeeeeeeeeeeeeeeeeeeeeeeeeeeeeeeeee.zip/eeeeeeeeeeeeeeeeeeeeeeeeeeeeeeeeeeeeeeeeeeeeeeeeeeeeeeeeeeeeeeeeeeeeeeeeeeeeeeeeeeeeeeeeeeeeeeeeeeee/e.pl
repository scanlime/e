#!/usr/bin/env perl

use utf8;
use strict;
use warnings;

for( ; ; )
	{
		printf"e";
	}
